#!/bin/bash -ex

cp -v ../unity-JBConsole/JBConsole/*.cs Assets/Scripts/JBConsole
cp -v ../unity-JBConsole/JBConsole/JBConsoleUnityUI/*.cs Assets/Scripts/JBConsole/JBConsoleUnityUI
cp -v ../unity-JBConsole-editor/JBConsole/Editor/*.cs Assets/Scripts/JBConsole/Editor